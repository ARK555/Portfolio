<?php
session_start();

// // Check if the admin is logged in
// if (!isset($_SESSION['admin_id'])) {
//     header("Location: login.php");
//     exit();
// }

// include('../includes/db_connect.php');
// ?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../assets/style.css">
  <title>Add New Blog Post</title>
</head>
<body>

<?php include('../includes/header.php'); ?>

<div class="container">
  <h1>Add New Blog Post</h1>

  <form action="add_blog_post.php" method="POST">
    <label for="title">Blog Title</label>
    <input type="text" id="title" name="title" required> <br>

    <label for="content">Content</label>
    <textarea id="content" name="content" rows="10" required></textarea> <br>

    <button type="submit" name="submit">Add Blog Post</button>
  </form>

  <?php
    if (isset($_POST['submit'])) {
        $title = $_POST['title'];
        $content = $_POST['content'];

        // Insert blog post into the database
        $sql = "INSERT INTO blog_posts (title, content) VALUES ('$title', '$content')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>Blog post added successfully!</p>";
        } else {
            echo "<p>Error: " . $conn->error . "</p>";
        }
    }
  ?>
</div>

<?php include('../includes/footer.php'); ?>

</body>
</html>
