<?php
session_start();
include('../includes/db_connect.php');

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch admin details from the database
    $sql = "SELECT * FROM admin WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Verify the password (stored as hashed)
        if (password_verify($password, $row['password'])) {
            // Store the admin's ID and username in the session
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_username'] = $row['username'];

            // Redirect to the add project page after successful login
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<p>Invalid username or password.</p>";
        }
    } else {
        echo "<p>Invalid username or password.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../assets/style.css">
  <title>Admin Login</title>
</head>
<body>

<div class="container">
  <h1>Admin Login</h1>
  <form action="login.php" method="POST">
    <label for="username">Username</label>
    <input type="text" id="username" name="username" required>

    <label for="password">Password</label>
    <input type="password" id="password" name="password" required>

    <button type="submit" name="login">Login</button>
  </form>
</div>

</body>
</html>
