<footer>
  <p>&copy; 2024 My Portfolio. All rights reserved.</p>
</footer>
