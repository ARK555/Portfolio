<header>
  <nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="projects.php">Projects</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="blog.php">Blog</a></li>
      <li><a href="admin/add_project.php">Add a Project</a></li>
      <li><a href="admin/add_blog_post.php">Add a Blog</a></li>
    </ul>
  </nav>
</header>
