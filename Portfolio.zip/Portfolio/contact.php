<?php include('includes/db_connect.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/contact.css">
  <title>Contact</title>
</head>
<body>

<?php include('includes/header.php'); ?>

<div class="container">
  <h1>Contact Me</h1>

  <form action="" method="POST">
    <label for="name">Your Name</label>
    <input type="text" id="name" name="name" required>

    <label for="email">Your Email</label>
    <input type="email" id="email" name="email" required>

    <label for="message">Your Message</label>
    <textarea id="message" name="message" required></textarea>

    <button type="submit" name="submit">Send Message</button>
  </form>

  <?php
    if (isset($_POST['submit'])) {
      $name = $_POST['name'];
      $email = $_POST['email'];
      $message = $_POST['message'];

      $sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$message')";

      if ($conn->query($sql) === TRUE) {
        echo "<p>Message sent successfully!</p>";
      } else {
        echo "<p>Error: " . $conn->error . "</p>";
      }
    }
  ?>
</div>

<?php include('includes/footer.php'); ?>

</body>
</html>
